<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm d-flex align-items-strech">
            <div class="card w-100">
                <div class="card-body">
                    <script type="module" src="https://us-east-1.online.tableau.com/javascripts/api/tableau.embedding.3.latest.min.js"></script>
                    <tableau-viz id="tableau-viz" src="<?php echo e($vizUrl); ?>" token="<?php echo e($token); ?>" width="900" height="740" hide-tabs toolbar="bottom">
                    </tableau-viz>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsTableau.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Asiatop\login-app\resources\views/home.blade.php ENDPATH**/ ?>