<footer id="sticky-footer" class="flex-shrink-0 py-2 bg-dark text-white-50">
    <div class="container text-center">
        <small>Copyright by ast</small>
    </div>
</footer>
<?php /**PATH C:\Users\USER\Documents\Asiatop\login-app\resources\views/layoutsTableau/footer.blade.php ENDPATH**/ ?>