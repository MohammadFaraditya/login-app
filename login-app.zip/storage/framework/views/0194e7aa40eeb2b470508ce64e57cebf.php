<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm d-flex align-items-strech">
                <div class="card w-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-between mb-10">
                            
                            <div class="container-lg">
                                <div class="table-responsive" style="overflow: hidden;">
                                    <div class="table-wrapper">
                                        <div class="table-title mb-4">
                                            <div class="row align-items-center mb-4">
                                                <div class="col d-flex align-items-center">
                                                    <h2 class="me-3 mb-0">Users</h2>
                                                    <a href="<?php echo e(route('ShowFormAddUser')); ?>">
                                                        <button type="button" class="btn btn-info add-new">
                                                            <i class="fa fa-plus"></i> Add New
                                                        </button>
                                                    </a>
                                                </div>
                                                <div class="col-auto ms-auto">
                                                    
                                                    <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="d-flex">
                                                        <input type="search" name="search" id="search-focus"
                                                            class="form-control me-2" style="width: 50%;"
                                                            placeholder="Search " value="<?php echo e(request()->get('search')); ?>">
                                                        <button type="submit" class="btn btn-primary me-2">Search</button>
                                                        <?php if(request()->has('search') && request()->get('search') !== ''): ?>
                                                            <a href="<?php echo e(route('dashboard')); ?>"
                                                                class="btn btn-secondary">Reset</a>
                                                        <?php endif; ?>
                                                    </form>
                                                </div>
                                            </div>

                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Username</th>
                                                        <th>Email</th>
                                                        <th>Role</th>
                                                        <th>Masa_Aktif</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($user->username); ?></td>
                                                            <td><?php echo e($user->email); ?></td>
                                                            <td><?php echo e(implode(', ', $user->getRoleNames()->toArray())); ?></td>
                                                            <td><?php echo e($user->masa_aktif_token); ?></td>
                                                            <td>
                                                                <a href="<?php echo e(route('ShowFormEditUser', $user->id)); ?>"
                                                                    class="btn btn-warning">
                                                                    Edit
                                                                </a>
                                                                <form action="<?php echo e(route('DeleteUser', $user->id)); ?>"
                                                                    method="POST" style="display:inline;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit"
                                                                        class="btn btn-danger">Delete</button>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                title: "<?php echo e(session('success')); ?>",
                icon: "success",
                draggable: true
            });
        </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "<?php echo e(session('error')); ?>",
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsDashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Asiatop\login-app\resources\views/dashboard.blade.php ENDPATH**/ ?>