<?php
namespace App\Http\Controllers;

use Carbon\Carbon;
use Firebase\JWT\JWT;

class TableauController extends Controller
{
    public function ShowHomeTableAU()
    {
        // Ambil data konfigurasi dari .env
        $connectedAppClientId  = env('CONNECTED_APP_CLIENT_ID');
        $connectedAppSecretKey = env('CONNECTED_APP_SECRET_KEY');
        $connectedAppSecretId  = env('CONNECTED_APP_SECRET_ID');
        $user                  = "asiatop@ast.asiatop.co.id";
        $vizUrl                = "https://prod-apsoutheast-a.online.tableau.com/t/asiatop/views/TryRevisiINA-TKinerjaSales/Dashboard_P_RSM_INA";

        // Membuat JWT
        $payload = [
            'iss' => $connectedAppClientId,                    // Issuer: Client ID
            'exp' => Carbon::now()->addMinutes(10)->timestamp, // Expiration time (10 menit)
            'jti' => (string) \Str::uuid(),                    // JWT ID, menggunakan UUID
            'aud' => 'tableau',                                // Audience
            'sub' => $user,                                    // Subject (user)
            'scp' => ['tableau:views:embed'],                  // Scope
        ];

        // Generate JWT
        $token = JWT::encode($payload, $connectedAppSecretKey, 'HS256', null, [
            'kid' => $connectedAppSecretId, // Key ID
            'iss' => $connectedAppClientId, // Issuer
        ]);

        // HTML embed Tableau dengan token JWT
        $htmlStr = "
    <h1>Tableau Connected Apps Demo</h1>
    <script type='module' src='https://us-east-1.online.tableau.com/javascripts/api/tableau.embedding.3.latest.min.js'></script>
    <tableau-viz id='tableau-viz' src='{$vizUrl}' token='{$token}' width='900' height='740' hide-tabs toolbar='bottom'>
    </tableau-viz>
    ";

        return response($htmlStr);
    }
}
