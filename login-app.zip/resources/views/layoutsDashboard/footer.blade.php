<footer id="sticky-footer" class="flex-shrink-0 py-2 bg-dark text-white-50">
    <div class="container text-center">
        <small>Copyright by ast</small>
    </div>
</footer>
