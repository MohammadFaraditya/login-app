<?php
namespace App\Http\Controllers;

class HomeController extends Controller
{
    public function ShowHomeTableAU()
    {
        return view('home');
    }
}
