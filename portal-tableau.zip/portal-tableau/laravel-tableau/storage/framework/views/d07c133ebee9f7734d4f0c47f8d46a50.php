<aside class="left-sidebar" style="z-index: 1070">
    <div class="scroll-sidebar" data-simplebar>
        <div class="d-flex mb-2 align-items-center justify-content-between">
            <a href="<?php echo e(route('homeTableAU')); ?>" class="text-nowrap logo-img ms-0 ms-md-1">
                <img src="<?php echo e(asset('/images/logos/HomeAsiatop.png')); ?>" width="100" alt="">
            </a>
            <div class="close-btn  d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
                <i class="ti ti-x fs-8"></i>
            </div>
        </div>
        <nav class="sidebar-nav ">
            <ul id="sidebarnav" class="mb-4 pb-2">
                <li class="nav-small-cap">
                    <i class="ti ti-dots nav-small-cap-icon fs-5"></i>
                    <span class="hide-menu">Home</span>
                </li>
                <?php $__currentLoopData = $sheet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="sidebar-item">
                    <a class="sidebar-link sidebar-link primary-hover-bg" href="<?php echo e(route('accessTableau', $sheets->idsheet)); ?>"
                        aria-expanded="false">
                        <span class="aside-icon p-2 bg-light-primary rounded-3">
                            <i class="ti ti-layout-dashboard fs-7 text-primary"></i>
                        </span>
                        <span class="hide-menu ms-2 ps-1"><?php echo e($sheets->name); ?></span>
                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH C:\Users\IT-Aplikasi SPV\Documents\ASIATOP\Data Terbaru\Asiatop\Asiatop\login-app\resources\views/layoutsTableau/sidebar.blade.php ENDPATH**/ ?>