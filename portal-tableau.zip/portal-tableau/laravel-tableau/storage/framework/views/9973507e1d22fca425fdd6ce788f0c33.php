

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Edit Role</h5>
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('EditRole', $role->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="roleName" class="form-label">Nama Role</label>
                            <input type="text" class="form-control" id="roleName" name="roleName" value="<?php echo e($role->name); ?>">
                            <?php $__errorArgs = ['roleName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="roleAccess" class="form-label">Role</label>
                            <select name="roleAccess[]" id="roleAccess" class="form-control" multiple>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Menampilkan semua permissions -->
                                <option value="<?php echo e($permission->name); ?>"
                                    <?php echo e(in_array($permission->name, $role->permissions->pluck('name')->toArray()) ? 'selected' : ''); ?>>
                                    <?php echo e($permission->name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['selectRole'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(route('ShowDashboardRole')); ?>" class="btn btn-danger">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php if(session('error')): ?>
<script>
    Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "<?php echo e(session('error')); ?>",
    });
</script>
<?php endif; ?>


<?php if(session('success')): ?>
<script>
    Swal.fire({
        title: "<?php echo e(session('success')); ?>",
        icon: "success",
        draggable: true
    });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsDashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Aplikasi SPV\Documents\ASIATOP\Data Terbaru\Asiatop\Asiatop\login-app\resources\views/dashboardAdministrator/dashboardRole/FormEditRole.blade.php ENDPATH**/ ?>