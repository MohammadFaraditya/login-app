

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row ">
        <div class="col-sm d-flex align-items-strech">
            <div class="card w-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-10">
                        <div class="container-lg">
                            <div class="table-responsive overflow-auto">
                                <div class="table-wrapper">
                                    <div class="table-title mb-4">
                                        <div class="row align-items-center mb-4">
                                            <div class="col d-flex align-items-center">
                                                <h2 class="me-3 mb-0">Daftar Sheet</h2>
                                                <a href="<?php echo e(route('ShowFormAddSheet')); ?>">
                                                    <button type="button" class="btn btn-info add-new">
                                                        <i class="fa fa-plus"></i> Add New
                                                    </button>
                                                </a>
                                            </div>
                                            <div class="col-auto ms-auto">
                                                
                                                <form method="GET" action="<?php echo e(route('ShowDashoardSheet')); ?>" class="d-flex">
                                                    <input type="search" name="search" id="search-focus"
                                                        class="form-control me-2" style="width: 50%;"
                                                        placeholder="Search " value="<?php echo e(request()->get('search')); ?>">
                                                    <button type="submit" class="btn btn-primary me-2">Search</button>
                                                    <?php if(request()->has('search') && request()->get('search') !== ''): ?>
                                                    <a href="<?php echo e(route('ShowDashoardSheet')); ?>"
                                                        class="btn btn-secondary">Reset</a>
                                                    <?php endif; ?>
                                                </form>
                                            </div>
                                        </div>

                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Nama Dashboard</th>
                                                    <th>Nama Sheet</th>
                                                    <th>Nama Sheet Tableau</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $sheet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheetItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permissionItem->id == $sheetItem->permission_id): ?>
                                                <tr>
                                                    <td><?php echo e($permissionItem->name); ?></td>
                                                    <td><?php echo e($sheetItem->name); ?></td>
                                                    <td><?php echo e($sheetItem->sheetName); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route( 'ShowFormEditSheet', $sheetItem->idsheet)); ?>" class="btn btn-warning">
                                                            Edit
                                                        </a>
                                                        <form action="<?php echo e(route('deleteSheet', $sheetItem->idsheet)); ?>" method="POST" style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="3">No sheets found</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(session('success')): ?>
<script>
    Swal.fire({
        title: "<?php echo e(session('success')); ?>",
        icon: "success",
        draggable: true
    });
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "<?php echo e(session('error')); ?>",
    });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsDashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Aplikasi SPV\Documents\ASIATOP\Data Terbaru\Asiatop\Asiatop\login-app\resources\views/dashboardAdministrator/dashboardSheet/daftarSheet.blade.php ENDPATH**/ ?>