<?php $__env->startSection('content'); ?>
<div id="container-home">
    <div class="row">
        <div class="col-sm d-flex align-items-stretch">
            <div class="card w-100">
                <div class="card-body" id="card">
                    <script type="module" src="<?php echo e(asset('js/tableau.js')); ?>"></script>
                    <tableau-viz id="tableau-viz" src="<?php echo e($vizUrl); ?>" token="<?php echo e($token); ?>" hide-tabs toolbar="bottom">
                        <?php if(isset($fieldFilter)): ?>
                            <viz-filter field="<?php echo e($fieldFilter); ?>" value="<?php echo e($jabatan); ?>" />
                        <?php endif; ?>
                    </tableau-viz>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsTableau.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Aplikasi SPV\Documents\ASIATOP\Data Terbaru\Asiatop\Asiatop\login-app\resources\views/home.blade.php ENDPATH**/ ?>