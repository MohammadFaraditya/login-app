<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0" id="container-home">
    <div class="m-2" style="height: auto;">
        <div id="tableau-wrapper" class="position-relative" style="height: 80vh;">
            <script type="module" src="<?php echo e(asset('js/tableau.js')); ?>"></script>
            <tableau-viz
                id="tableau-viz"
                src="<?php echo e($vizUrl); ?>"
                token="<?php echo e($token); ?>"
                hide-tabs
                toolbar="hidden"
                style="width: 100%; height: 100%; display: block;"
            >
                <?php if(isset($fieldFilter)): ?>
                    <viz-filter field="<?php echo e($fieldFilter); ?>" value="<?php echo e($jabatan); ?>" />
                <?php endif; ?>
            </tableau-viz>

            <button id="fullscreenBtn" class="btn btn-primary btn-sm fullscreen-btn">
                <i class="fas fa-expand"></i> Fullscreen
            </button>
        </div>
    </div>
</div>

<style>
    /* Your existing CSS remains the same */
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const fullscreenBtn = document.getElementById('fullscreenBtn');
        const tableauWrapper = document.getElementById('tableau-wrapper');
        const tableauVizEl = document.getElementById('tableau-viz');

        // Initialize viz variable
        let viz = null;

        // More robust viz initialization
        function initializeViz() {
            if (tableauVizEl && tableauVizEl.viz) {
                viz = tableauVizEl.viz;
                console.log('Tableau Viz initialized successfully');
                return true;
            }
            return false;
        }

        // Safe resize function with error handling
        function safeResize() {
            if (viz && typeof viz.resize === 'function') {
                try {
                    viz.resize();
                    console.log('Viz resized successfully');
                } catch (e) {
                    console.error('Error resizing viz:', e);
                }
            } else {
                console.warn('Viz not ready for resizing');
                // Try to initialize if not done yet
                if (initializeViz()) {
                    safeResize();
                }
            }
        }

        // Event listener for tableau initialization
        if (tableauVizEl) {
            tableauVizEl.addEventListener('firstinteractive', function() {
                initializeViz();
                setTimeout(safeResize, 300);
            });
        } else {
            console.error('Tableau Viz element not found');
        }

        // Fullscreen button handler
        fullscreenBtn.addEventListener('click', function() {
            if (!document.fullscreenElement) {
                if (tableauWrapper.requestFullscreen) {
                    tableauWrapper.requestFullscreen()
                        .then(() => {
                            setTimeout(safeResize, 300);
                            setTimeout(safeResize, 800); // Second resize after transition
                        })
                        .catch(err => {
                            console.error('Fullscreen error:', err);
                        });
                }
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                }
            }
        });

        // Fullscreen change handler
        function handleFullscreenChange() {
            if (document.fullscreenElement) {
                fullscreenBtn.innerHTML = '<i class="fas fa-compress"></i> Exit Fullscreen';
            } else {
                fullscreenBtn.innerHTML = '<i class="fas fa-expand"></i> Fullscreen';
            }
            safeResize();
        }

        document.addEventListener('fullscreenchange', handleFullscreenChange);
        document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutsTableau.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Aplikasi SPV\Documents\ASIATOP\Data Terbaru\Asiatop\Asiatop\login-app\resources\views/home.blade.php ENDPATH**/ ?>